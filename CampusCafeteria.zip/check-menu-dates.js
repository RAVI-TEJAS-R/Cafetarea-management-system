import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
try {
    const result = await connection.execute(`
    SELECT
      TO_CHAR(md.menu_date, 'YYYY-MM-DD') AS menu_date,
      COUNT(mi.menu_item_id) AS item_count
    FROM menu_dates md
    LEFT JOIN menu_items mi
      ON mi.menu_date_id = md.menu_date_id
    GROUP BY md.menu_date
    ORDER BY md.menu_date
  `);
    for (const row of result.rows ?? []) {
        console.log(row);
    }
}
finally {
    await connection.close();
}
