import bcrypt from "bcryptjs";
import { pool } from "./db.js";
const connection = await pool.getConnection();
try {
    const staffPasswordHash = await bcrypt.hash("Staff@123", 12);
    const adminPasswordHash = await bcrypt.hash("Admin@123", 12);
    await connection.execute(`
    UPDATE users
    SET password_hash = :password_hash
    WHERE user_id = 2
    `, {
        password_hash: staffPasswordHash
    });
    await connection.execute(`
    UPDATE users
    SET password_hash = :password_hash
    WHERE user_id = 3
    `, {
        password_hash: adminPasswordHash
    });
    await connection.commit();
    console.log("Demo STAFF password set: Staff@123");
    console.log("Demo ADMIN password set: Admin@123");
}
catch (error) {
    await connection.rollback();
    console.error(error);
}
finally {
    await connection.close();
    await pool.close();
}
