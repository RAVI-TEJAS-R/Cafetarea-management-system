import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
const result = await connection.execute(`
  SELECT
      argument_name AS "PARAMETER_NAME",
      position AS "POSITION",
      data_type AS "DATA_TYPE",
      type_name AS "TYPE_NAME",
      in_out AS "IN_OUT"
  FROM user_arguments
  WHERE object_name = 'PLACE_ORDER'
    AND package_name IS NULL
  ORDER BY position
  `, [], {
    outFormat: oracledb.OUT_FORMAT_OBJECT
});
console.table(result.rows ?? []);
await connection.close();
