import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
const result = await connection.execute(`
  SELECT
      table_name AS TABLE_NAME,
      constraint_name AS CONSTRAINT_NAME,
      constraint_type AS CONSTRAINT_TYPE,
      status AS STATUS,
      search_condition AS SEARCH_CONDITION
  FROM user_constraints
  WHERE table_name IN (
      'ROLES',
      'USERS',
      'MENU_DATES',
      'MENU_ITEMS',
      'INGREDIENTS',
      'ITEM_INGREDIENTS',
      'STOCK',
      'PICKUP_WINDOWS',
      'ORDERS',
      'ORDER_LINES',
      'ORDER_STATUS_HISTORY'
  )
  ORDER BY table_name, constraint_type, constraint_name
  `, [], { outFormat: oracledb.OUT_FORMAT_OBJECT });
console.table((result.rows ?? []).map((row) => ({
    TABLE_NAME: row.TABLE_NAME,
    CONSTRAINT_NAME: row.CONSTRAINT_NAME,
    TYPE: row.CONSTRAINT_TYPE,
    STATUS: row.STATUS
})));
await connection.close();
