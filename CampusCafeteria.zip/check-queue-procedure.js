import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
const options = {
    outFormat: oracledb.OUT_FORMAT_OBJECT
};
/* Procedure status */
const procedure = await connection.execute(`
  SELECT
      object_name AS "PROCEDURE_NAME",
      object_type AS "OBJECT_TYPE",
      status AS "STATUS"
  FROM user_objects
  WHERE object_type = 'PROCEDURE'
    AND object_name = 'GET_PICKUP_QUEUE'
  `, [], options);
console.log("PROCEDURE STATUS");
console.table(procedure.rows ?? []);
/* Procedure parameters */
const parameters = await connection.execute(`
  SELECT
      argument_name AS "PARAMETER_NAME",
      position AS "POSITION",
      data_type AS "DATA_TYPE",
      type_name AS "TYPE_NAME",
      in_out AS "IN_OUT"
  FROM user_arguments
  WHERE object_name = 'GET_PICKUP_QUEUE'
    AND package_name IS NULL
  ORDER BY position
  `, [], options);
console.log("PROCEDURE PARAMETERS");
console.table(parameters.rows ?? []);
await connection.close();
