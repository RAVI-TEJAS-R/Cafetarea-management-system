import jwt from "jsonwebtoken";
const JWT_SECRET = process.env.JWT_SECRET ?? (() => {
    throw new Error("JWT_SECRET is not configured");
})();
export function authenticateToken(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({
            error: "Authentication token required"
        });
    }
    const token = authHeader.substring(7);
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    }
    catch {
        return res.status(401).json({
            error: "Invalid or expired authentication token"
        });
    }
}
export function requireRole(...allowedRoles) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                error: "Authentication required"
            });
        }
        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({
                error: "Insufficient permissions"
            });
        }
        next();
    };
}
