import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
try {
    const result = await connection.execute(`
    SELECT object_name, object_type, status
    FROM user_objects
    WHERE object_name = 'GET_PICKUP_QUEUE'
  `);
    console.table(result.rows);
}
finally {
    await connection.close();
}
