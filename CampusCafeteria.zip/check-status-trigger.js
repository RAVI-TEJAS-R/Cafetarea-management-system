import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
try {
    const result = await connection.execute("SELECT trigger_name, status, triggering_event FROM user_triggers WHERE trigger_name = 'TRG_ORDER_STATUS_HISTORY'");
    console.table(result.rows);
}
finally {
    await connection.close();
}
