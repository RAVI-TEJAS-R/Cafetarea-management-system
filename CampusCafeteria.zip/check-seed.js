import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
const tables = [
    "ROLES",
    "USERS",
    "MENU_DATES",
    "MENU_ITEMS",
    "INGREDIENTS",
    "ITEM_INGREDIENTS",
    "STOCK",
    "PICKUP_WINDOWS",
    "ORDERS",
    "ORDER_LINES",
    "ORDER_STATUS_HISTORY"
];
try {
    for (const table of tables) {
        const result = await connection.execute("SELECT COUNT(*) AS CNT FROM " + table);
        const row = result.rows?.[0];
        console.log(table + ": " + (row?.[0] ?? 0));
    }
}
finally {
    await connection.close();
}
