import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
const tables = [
    "ROLES",
    "USERS",
    "MENU_DATES",
    "MENU_ITEMS",
    "INGREDIENTS",
    "ITEM_INGREDIENTS",
    "STOCK",
    "PICKUP_WINDOWS",
    "ORDERS",
    "ORDER_LINES",
    "ORDER_STATUS_HISTORY"
];
const rows = [];
for (const table of tables) {
    const result = await connection.execute(`SELECT COUNT(*) AS COUNT FROM ${table}`, [], { outFormat: oracledb.OUT_FORMAT_OBJECT });
    rows.push({
        TABLE_NAME: table,
        ROW_COUNT: Number(result.rows?.[0]?.COUNT ?? 0)
    });
}
console.table(rows);
await connection.close();
