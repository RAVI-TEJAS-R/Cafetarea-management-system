import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
try {
    console.log("DAILY ORDER SUMMARY");
    let result = await connection.execute(`
    SELECT *
    FROM vw_daily_order_summary
    ORDER BY order_date
  `);
    console.table(result.rows);
    console.log("MENU STOCK STATUS");
    result = await connection.execute(`
    SELECT *
    FROM vw_menu_stock_status
    ORDER BY menu_item_id
  `);
    console.table(result.rows);
    console.log("ORDER DETAILS");
    result = await connection.execute(`
    SELECT *
    FROM vw_order_details
    ORDER BY order_id
  `);
    console.table(result.rows);
}
finally {
    await connection.close();
}
