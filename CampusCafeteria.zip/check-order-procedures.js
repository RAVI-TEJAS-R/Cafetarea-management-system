import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
const result = await connection.execute(`
  SELECT
      object_name AS "PROCEDURE_NAME",
      object_type AS "OBJECT_TYPE",
      status AS "STATUS"
  FROM user_objects
  WHERE object_type = 'PROCEDURE'
    AND object_name IN (
      'PLACE_ORDER',
      'CANCEL_ORDER'
    )
  ORDER BY object_name
  `, [], {
    outFormat: oracledb.OUT_FORMAT_OBJECT
});
console.log("PROCEDURE STATUS");
console.table(result.rows ?? []);
const errors = await connection.execute(`
  SELECT
      name AS "PROCEDURE_NAME",
      type AS "OBJECT_TYPE",
      line AS "LINE_NUMBER",
      position AS "POSITION",
      text AS "ERROR_MESSAGE"
  FROM user_errors
  WHERE name IN ('PLACE_ORDER', 'CANCEL_ORDER')
  ORDER BY name, sequence
  `, [], {
    outFormat: oracledb.OUT_FORMAT_OBJECT
});
console.log("COMPILATION ERRORS");
console.table(errors.rows ?? []);
await connection.close();
