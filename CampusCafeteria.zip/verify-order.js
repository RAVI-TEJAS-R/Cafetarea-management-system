import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
const options = {
    outFormat: oracledb.OUT_FORMAT_OBJECT
};
/* ORDERS */
const orders = await connection.execute(`
  SELECT
      order_id AS "Order ID",
      user_id AS "User ID",
      pickup_window_id AS "Pickup Window ID",
      pickup_code AS "Pickup Code",
      order_status AS "Order Status",
      total_amount AS "Total Amount"
  FROM orders
  ORDER BY order_id
  `, [], options);
console.log("ORDERS");
console.table(orders.rows ?? []);
/* ORDER LINES */
const orderLines = await connection.execute(`
  SELECT
      order_id AS "Order ID",
      menu_item_id AS "Menu Item ID",
      quantity AS "Quantity",
      unit_price AS "Unit Price"
  FROM order_lines
  ORDER BY order_id, menu_item_id
  `, [], options);
console.log("ORDER_LINES");
console.table(orderLines.rows ?? []);
/* STOCK */
const stock = await connection.execute(`
  SELECT
      menu_item_id AS "Menu Item ID",
      available_qty AS "Available Quantity"
  FROM stock
  ORDER BY menu_item_id
  `, [], options);
console.log("STOCK");
console.table(stock.rows ?? []);
/* PICKUP WINDOWS */
const pickupWindows = await connection.execute(`
  SELECT
      pickup_window_id AS "Pickup Window ID",
      capacity AS "Capacity",
      reserved_count AS "Reserved Count"
  FROM pickup_windows
  ORDER BY pickup_window_id
  `, [], options);
console.log("PICKUP_WINDOWS");
console.table(pickupWindows.rows ?? []);
/* ORDER STATUS HISTORY */
const history = await connection.execute(`
  SELECT
      order_id AS "Order ID",
      old_status AS "Old Status",
      new_status AS "New Status",
      changed_by AS "Changed By"
  FROM order_status_history
  ORDER BY history_id
  `, [], options);
console.log("ORDER_STATUS_HISTORY");
console.table(history.rows ?? []);
await connection.close();
