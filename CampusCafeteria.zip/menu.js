import { Router } from "express";
import { pool } from "../db.js";
import { authenticateToken, requireRole } from "../middleware/auth.js";
const router = Router();
router.get("/", authenticateToken, requireRole("STUDENT", "STAFF", "ADMIN"), async (req, res) => {
    let connection;
    try {
        const date = String(req.query.date ?? "");
        if (!date) {
            return res.status(400).json({
                error: "date query parameter is required. Use YYYY-MM-DD."
            });
        }
        connection = await pool.getConnection();
        const menuResult = await connection.execute(`
      SELECT
          mi.menu_item_id AS "menuItemId",
          mi.item_name AS "itemName",
          mi.description AS "description",
          mi.price AS "price",
          mi.is_available AS "isAvailable"
      FROM menu_dates md
      JOIN menu_items mi
        ON mi.menu_date_id = md.menu_date_id
      WHERE md.menu_date = TO_DATE(:menu_date, 'YYYY-MM-DD')
        AND md.is_published = 'Y'
      ORDER BY mi.menu_item_id
      `, { menu_date: date }, { outFormat: 4002 });
        const ingredientResult = await connection.execute(`
      SELECT
          ii.menu_item_id AS "menuItemId",
          i.ingredient_name AS "ingredientName"
      FROM item_ingredients ii
      JOIN ingredients i
        ON i.ingredient_id = ii.ingredient_id
      JOIN menu_items mi
        ON mi.menu_item_id = ii.menu_item_id
      JOIN menu_dates md
        ON md.menu_date_id = mi.menu_date_id
      WHERE md.menu_date = TO_DATE(:menu_date, 'YYYY-MM-DD')
      ORDER BY ii.menu_item_id, i.ingredient_name
      `, { menu_date: date }, { outFormat: 4002 });
        const pickupResult = await connection.execute(`
      SELECT
          pickup_window_id AS "pickupWindowId",
          TO_CHAR(start_time, 'HH24:MI') AS "startTime",
          TO_CHAR(end_time, 'HH24:MI') AS "endTime",
          capacity AS "capacity",
          reserved_count AS "reservedCount",
          capacity - reserved_count AS "availableCapacity"
      FROM pickup_windows
      WHERE window_date = TO_DATE(:menu_date, 'YYYY-MM-DD')
      ORDER BY start_time
      `, { menu_date: date }, { outFormat: 4002 });
        const ingredientsByItem = new Map();
        for (const ingredient of ingredientResult.rows ?? []) {
            if (!ingredientsByItem.has(ingredient.menuItemId)) {
                ingredientsByItem.set(ingredient.menuItemId, []);
            }
            ingredientsByItem
                .get(ingredient.menuItemId)
                .push(ingredient.ingredientName);
        }
        const items = (menuResult.rows ?? []).map((item) => ({
            ...item,
            ingredients: ingredientsByItem.get(item.menuItemId) ?? []
        }));
        res.json({
            date,
            items,
            pickupWindows: pickupResult.rows ?? []
        });
    }
    catch (error) {
        console.error("Menu API error:", error);
        res.status(500).json({
            error: "Failed to retrieve menu."
        });
    }
    finally {
        if (connection) {
            await connection.close();
        }
    }
});
export default router;
