import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
try {
    const result = await connection.execute(`
    BEGIN
      place_order(
        p_user_id          => :user_id,
        p_pickup_window_id => :pickup_window_id,
        p_menu_item_ids    => SYS.ODCINUMBERLIST(:item1, :item2),
        p_quantities       => SYS.ODCINUMBERLIST(:qty1, :qty2),
        p_order_id         => :order_id,
        p_pickup_code      => :pickup_code,
        p_total_amount     => :total_amount
      );
    END;
    `, {
        user_id: 1,
        pickup_window_id: 1,
        item1: 1,
        item2: 2,
        qty1: 1,
        qty2: 2,
        order_id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
        pickup_code: { dir: oracledb.BIND_OUT, type: oracledb.STRING, maxSize: 50 },
        total_amount: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
    });
    console.log("Order created successfully.");
    console.log("Order ID:", result.outBinds.order_id[0]);
    console.log("Pickup Code:", result.outBinds.pickup_code[0]);
    console.log("Total Amount:", result.outBinds.total_amount[0]);
}
catch (error) {
    console.error("Order failed:", error);
}
finally {
    await connection.close();
}
