import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
const result = await connection.execute("SELECT table_name AS TABLE_NAME FROM user_tables ORDER BY table_name", [], {
    outFormat: oracledb.OUT_FORMAT_OBJECT
});
console.table(result.rows);
await connection.close();
