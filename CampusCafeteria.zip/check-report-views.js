import oracledb from "oracledb";
import dotenv from "dotenv";
dotenv.config();
const connection = await oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
});
const result = await connection.execute(`
  SELECT
      object_name AS "VIEW_NAME",
      object_type AS "OBJECT_TYPE",
      status AS "STATUS"
  FROM user_objects
  WHERE object_type = 'VIEW'
    AND object_name IN (
      'VW_DAILY_ORDER_SUMMARY',
      'VW_MENU_STOCK_STATUS',
      'VW_ORDER_DETAILS'
    )
  ORDER BY object_name
  `, [], {
    outFormat: oracledb.OUT_FORMAT_OBJECT
});
console.table(result.rows ?? []);
await connection.close();
